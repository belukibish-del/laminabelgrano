/* Lente DIA · Manuel Belgrano · IA al Colorado
   Lógica de la cámara AR, marcador y video. Requiere index.html y las librerías A-Frame y MindAR. */
/* ===== Ajustes ===== */
const CFG = {
  video: "video/belgrano.mp4",     // tu video del humano digital hablando
  lamina: "lamina/belgrano.png",   // el PNG de la lámina (la página arma el marcador con esta imagen)
  marcador: "targets.mind",        // opcional: si existe, se usa este y no se compila
  version: "v1",                   // cambiá esto si cambiás la lámina (invalida el marcador guardado)
  x: 0, y: 0.17, ancho: 0.9        // posición/tamaño del video sobre la lámina (1 = ancho de la lámina)
};
const $ = s => document.querySelector(s);
const msg = (t, err) => { const m = $("#msg"); m.textContent = t; m.className = err ? "err" : "" };
class Faltante extends Error {}

async function existe(url){ try{ const r = await fetch(url, {method:"HEAD", cache:"no-store"}); return r.ok }catch(e){ return false } }
const cargarImg = src => new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => no(new Error("img")); i.src = src });

/* Guardado del marcador para no recompilar en cada visita */
const idb = () => new Promise((ok, no) => { const r = indexedDB.open("lente-dia", 1); r.onupgradeneeded = () => r.result.createObjectStore("t"); r.onsuccess = () => ok(r.result); r.onerror = () => no(r.error) });
async function idbGet(k){ try{ const d = await idb(); return await new Promise(ok => { const q = d.transaction("t").objectStore("t").get(k); q.onsuccess = () => ok(q.result || null); q.onerror = () => ok(null) }) }catch(e){ return null } }
async function idbSet(k, v){ try{ const d = await idb(); d.transaction("t", "readwrite").objectStore("t").put(v, k) }catch(e){} }

/* Obtiene la URL del marcador: archivo existente, copia guardada o compilación en el navegador */
async function obtenerMarcador(){
  if(await existe(CFG.marcador)) return CFG.marcador;
  const key = "marcador-" + CFG.version;
  const guardado = await idbGet(key);
  if(guardado) return URL.createObjectURL(new Blob([guardado]));
  if(!(await existe(CFG.lamina))) throw new Faltante("Falta la lámina: subí el PNG a tu repositorio como " + CFG.lamina + " (ver README).");
  if(!window.MindCompiler) throw new Error("No se cargó el compilador de MindAR. Revisá tu conexión y recargá.");
  msg("Preparando la lámina por primera vez… puede tardar un minuto. No cierres la página.");
  const img = await cargarImg(CFG.lamina);
  const sc = Math.min(1, 900 / img.naturalWidth);               // se reduce para que el celular pueda procesarla
  const c = document.createElement("canvas");
  c.width = Math.round(img.naturalWidth * sc); c.height = Math.round(img.naturalHeight * sc);
  c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
  const chica = await cargarImg(c.toDataURL("image/png"));
  const comp = new window.MindCompiler();
  await comp.compileImageTargets([chica], p => msg("Preparando la lámina… " + Math.round(p) + "%"));
  const buf = await comp.exportData();
  await idbSet(key, buf);
  return URL.createObjectURL(new Blob([buf]));
}

function armarEscena(src, conVideo){
  $("#host").innerHTML =
   `<a-scene id="scene" mindar-image="imageTargetSrc: ${src}; autoStart: false; filterMinCF: 0.0001; filterBeta: 0.001; uiLoading: no; uiScanning: no; uiError: no"
      color-space="sRGB" renderer="colorManagement: true, physicallyCorrectLights: true" vr-mode-ui="enabled: false" device-orientation-permission-ui="enabled: false">
      <a-camera position="0 0 0" look-controls="enabled: false"></a-camera>
      <a-entity id="target" mindar-image-target="targetIndex: 0">
        <a-plane id="screen" position="${CFG.x} ${CFG.y} 0.01" width="${CFG.ancho}" height="${CFG.ancho}" ${conVideo ? 'material="shader: flat; src: #vid"' : 'color="#2f7fc0" opacity="0.7"'}></a-plane>
      </a-entity>
    </a-scene>`;
  return $("#scene");
}

$("#go").addEventListener("click", async () => {
  const btn = $("#go"); btn.disabled = true; btn.textContent = "Iniciando…"; msg("");
  try{
    // 1) Video (si falta, la lente funciona igual en modo prueba con un panel de color)
    let vid = null;
    if(await existe(CFG.video)){
      vid = document.createElement("video");
      Object.assign(vid, {id:"vid", src:CFG.video, loop:true, preload:"auto", crossOrigin:"anonymous"});
      vid.setAttribute("playsinline", ""); vid.setAttribute("webkit-playsinline", "");
      document.body.appendChild(vid); vid.style.display = "none";
      vid.addEventListener("loadedmetadata", () => {
        const h = CFG.ancho * (vid.videoHeight / vid.videoWidth);
        const s = $("#screen"); if(s){ s.setAttribute("height", h) }
      });
      vid.muted = false; await vid.play(); vid.pause(); vid.currentTime = 0;   // desbloquea el sonido con este toque
    }else{
      $("#plateTxt").textContent = "Modo prueba: falta " + CFG.video + " · IA al Colorado";
    }
    // 2) Marcador
    const src = await obtenerMarcador();
    msg("Abriendo la cámara…");
    // 3) Escena AR
    const scene = armarEscena(src, !!vid);
    if(!scene.hasLoaded) await new Promise(ok => scene.addEventListener("loaded", ok, {once:true}));
    await scene.systems["mindar-image-system"].start();
    const t = $("#target");
    t.addEventListener("targetFound", () => { $("#scan").classList.add("hide"); if(vid) vid.play().catch(() => { vid.muted = true; vid.play() }) });
    t.addEventListener("targetLost",  () => { $("#scan").classList.remove("hide"); if(vid) vid.pause() });
    $("#start").style.display = "none"; $("#plate").style.display = "block"; $("#scan").style.display = "block";
  }catch(e){
    btn.disabled = false; btn.textContent = "Activar cámara";
    if(e instanceof Faltante) msg(e.message, true);
    else if(e && e.name === "NotAllowedError") msg("Necesito permiso para usar la cámara. Habilitalo en el navegador y probá de nuevo.", true);
    else msg("No se pudo iniciar: " + (e && e.message ? e.message : "revisá la cámara y que la página esté en https."), true);
  }
});
